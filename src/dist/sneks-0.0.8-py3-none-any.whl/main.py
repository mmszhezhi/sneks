from snek import example

def start():
    example.fuck()